const ServerlessPluginSplitStacks = require('serverless-plugin-split-stacks');

const NUMBER_OF_BINS = 10;
let COUNT = 0;

ServerlessPluginSplitStacks.resolveMigration = function (resource, logicalId, serverless) {
  COUNT += 1;
  const bin = COUNT % NUMBER_OF_BINS;
  if (resource.Type === 'AWS::AppSync::Resolver') {
    return {
      destination: `GraphQLResolverStack${Math.abs(bin)}`,
      allowSuffix: true,
    };
  }

  if (resource.Type === 'AWS::AppSync::FunctionConfiguration') {
    return {
      destination: `FunctionConfigurationStack${Math.abs(bin)}`,
      allowSuffix: true,
    };
  }

  // Fallback to default:
  return this.stacksMap[resource.Type];
};
